# -*- coding: utf-8 -*-
"""
Created on Sun Oct  3 21:16:15 2021

@author: CastroM
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def cal_hedging_type(n,theta,Dt,Srt):
# eta, Hedging_type, WA_It, WA_Ft, mRCO = cal_hedging_type(n,theta,Dt,Srt)
# function to estimate the hedging type depending on the selected rule
#
# Input
# n            :
# theta        : weighting factor of loss function [0, 1]    
# Dt           : Required demand at time t
# Srt          : Required storage at time t+1
#
# Output
# eta          : Inverse weighted target ratio
# Hedging_type : For hedging --> 'Type I' or 'Type II', For SOR --> 'SOR' 
# WA_It         : Available initial water at time t (hedging)
# WA_Ft         : Available final water at time t (hedging)
# mRCO         : Slope of hedging (if there is hedging)
# 


    # eta = Inverse weighted target ratio   
    eta = (1-theta)/theta*Dt/Srt;
  
    # Determine which type of operation is performed
    if (theta == 1): # Standard operation rule SOR (NO HEDGING)
        Hedging_type = 'SOR';
    else:  # Hedging type
        if (eta > 1):
            Hedging_type = 'Type II'
        else: # (eta < 1)
            Hedging_type = 'Type I'
   
            # Available Water Initial
            b    = 1/(n-1)
            tmp1 = max(Dt*(1-eta**b),0)
            tmp2 = max(Srt*(1-(1/eta)**b),0)
            WA_It = max(tmp1,tmp2)
  
            # Available Water Final
            WA_Ft = Dt + Srt
  
  
    # Slope of Hedging
    if Hedging_type == 'Type I':
        mRCO = (Dt-WA_It)/(WA_Ft - WA_It)
      
    if Hedging_type == 'Type II':
        mRCO = (Dt)/(WA_Ft - WA_It)
  
    if Hedging_type == 'SOR':
        WA_It = Dt
        WA_Ft = Dt
        mRCO = 0
    #print(Hedging_type)
    return eta, Hedging_type, WA_It, WA_Ft, mRCO

def cal_hedging_Rt(Hedging_type,WA_t,WA_It,WA_Ft,Dt,mRCO):
# def cal_hedging_Rt(Hedging_type,WA_t,WA_It,WA_Ft,Dt,mRCO)  
# estimate the optimal release Rt based on 
# the water availability WA_t and the Demand Dt
#
# Input 
# Hedging_type : For hedging --> 'Type I' or 'Type II', For SOR --> 'SOR'
# WA_t          : Avaialable water inreservoir at time t
# WA_It         : Available initial water at time t (hedging)
# WA_Ft         : Available final water at time t (hedging)
# Dt           : Required demand at time t
# mRCO         : Slope of hedging (if there is hedging)
#
# Output:
# Rt  : Reservoir Release
#
    #print(Hedging_type)
    if (WA_t <= WA_It): # Under requirement
        if Hedging_type == 'Type I':
            Rt = WA_t
        if Hedging_type == 'Type II':
            Rt = 0
        if Hedging_type == 'SOR':
            Rt = WA_t
    elif (WA_t <= WA_Ft): # Hedging
        if Hedging_type == 'Type I':
            Rt = mRCO*WA_t + WA_It*(1-mRCO)
        if Hedging_type == 'Type II':
            Rt = mRCO*(WA_t - WA_It)
        if Hedging_type == 'SOR':
            if (WA_t < Dt):
                Rt = WA_t
            else:
                Rt = Dt
    else: # No hedging, full delivery of Demand
        Rt = Dt
        
    return Rt


def run_riogrande(data,n_TS,theta_TS,Dt_TS,Srt_TS,K):

    # number of time stamps
    ntimes = len(data)

    # Curves of reservoir
    # Elevation vs Volume : Elevation = f(Volume^2)
    V2E = [-0.000187,	0.132624,	0.092380]
    # Area vs Elevation : Area = f(Elevation^2)
    E2A = [ 0.007563,	0.354194,	5.129535]
    # Vtest = 100; Etest = polyval(V2E,Vtest); Atest = polyval(E2A,Etest);

    # Incoming flow [Mm3]
    Qin_TS       = data['Qin']

    # Evaporation [mm/d] - Known
    Evap_TS      = data['ET']

    # Evaporation [Mm3] - Function of Reservoir surface area
    Evap_TS2     = np.zeros((ntimes,1))

    # Elevation [m]
    Elev_TS      = np.zeros((ntimes,1))

    # Area [Mm2]
    Area_TS      = np.zeros((ntimes,1))

    # Volume in current storage [Mm3]
    Vol_TS    = np.zeros((ntimes+1,1)) # one more for t = 0
    Vo        = data['VOL'][0]/1e6    # Initial Reservoir Volume [Mm3]
    Vol_TS[0] = Vo                   # Known from Observed TS

    # Results of hedging Available Water, Release, Spill, Water Balance
    WA_TS       = np.zeros((ntimes,1))
    Rt_TS       = np.zeros((ntimes,1))
    Spt_TS      = np.zeros((ntimes,1))
    WB_TS       = np.zeros((ntimes,1))
    
    #tic;
    for t in range(ntimes):
        # Estimate values for current month
        curr_month = (data['month_idx'][t] % 12);
        if curr_month == 0:
            curr_month = 12
        curr_month = curr_month - 1
        
        Dt    = Dt_TS[curr_month]
        Srt   = Srt_TS[curr_month]
        n     = n_TS[curr_month]
        theta = theta_TS[curr_month]
        
        # Estimate hedging values
        eta,Hedg_type,WA_It,WA_Ft,mRCO = cal_hedging_type(n,theta,Dt,Srt)
        
        # Update current Reservoir status (Elevation , Area, Evaporation)
        Elev_TS[t]  = np.polyval(V2E,Vol_TS[t]);
        Area_TS[t]  = np.polyval(E2A,Elev_TS[t]);
        Evap_TS2[t] = (Evap_TS[t]/1000)*Area_TS[t];
        
        # Estimate Available Water
        WA_t         = Vol_TS[t] + Qin_TS[t] - Evap_TS2[t]
        WA_TS[t]   = WA_t
        # Calculate hedging
        Rt          = cal_hedging_Rt(Hedg_type,WA_t[0],WA_It,WA_Ft,Dt,mRCO)
        
        Rt_TS[t]    = Rt
        
        # Update Volume --> t+1 Or possible Spill --> t
        if (WA_t - Rt) <= K[curr_month]: # No Spill
            Vol_TS[t+1] = WA_t - Rt
            Spt_TS[t]   = 0.0
        else:
            Vol_TS[t+1] = K[curr_month] # Spill!
            Spt_TS[t]   = (WA_t - Rt) - K[curr_month]
    
    #plt.plot(Elev_TS)
    #plt.plot(Area_TS)
    #plt.plot(Evap_TS2)
    plt.plot(Vol_TS)
    plt.plot(data['VOL'].values/1e6)
    #toc
    err  = np.transpose(data['VOL'].values/1e6)-np.transpose(Vol_TS[:-1])
    r    = np.corrcoef(np.transpose(Vol_TS[:-1]),np.transpose(data['VOL'])/1e6)
    betan = (np.mean(Vol_TS[:-1])-np.mean(data['VOL'].values/1e6))/np.std(data['VOL'].values/1e6)
    beta = np.mean(np.transpose(Vol_TS[:-1]))/np.mean(np.transpose(data['VOL'].values/1e6))
    alpha = np.std(np.transpose(Vol_TS[:-1]))/np.std(np.transpose(data['VOL'].values/1e6))
    RMSE = np.sqrt(np.sum(err**2)/ntimes)
    return [r[0,1], beta, alpha, RMSE, betan]




# load time series 
data = pd.read_csv ('IN_Riogrande.csv',header=1)
data.keys()

# Hedging and Carryover parameters
n_TS     = [3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0] # exponent n > 1
theta_TS = [0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2] # proportion of Benefit release [0, 1.0]

# Demand required
Dt_TS    = [3.00, 2.00, 2.50, 4.00, 1.00, 2.00, 4.00, 3.00, 2.00, 1.00, 2.00, 2.00]

# Storage required at end of period
Srt_TS   = [70.0, 50.0, 60.0, 90.0, 90.0, 80.0, 70.0, 90.0, 80.0, 60.0, 50.0, 70.0]

# useful Volume of reservoir
K        = [149.658, 149.658, 149.658, 149.658, 149.658, 149.658, 149.658, 149.658, 149.658, 149.658, 149.658, 149.658]


objs = run_riogrande(data,n_TS,theta_TS,Dt_TS,Srt_TS,K)