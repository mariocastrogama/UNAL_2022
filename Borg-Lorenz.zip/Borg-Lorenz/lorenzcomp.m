function [f,c] = lorenzcomp(x)
  global nfuneval  
  global maxfuneval
  % Known values of Lorenz
  po = [28, 10, 8/3];
  [to, yo] = mylorenz(po);
  
  % Estimate with x
  [ti, yi] = mylorenz(x);
  yq = interp1(ti,yi,to);
  
  % Obtain the absolute error for each variable
  f = sum(abs(yq-yo));
  c = [];
  nfuneval = nfuneval + 1;
  if (mod(nfuneval,maxfuneval/10) == 0)
    disp(['feval : ',num2str(nfuneval)]);
  end
end