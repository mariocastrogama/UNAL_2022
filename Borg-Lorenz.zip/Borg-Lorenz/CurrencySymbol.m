function currency = currSym( str )
%currSym.m
%
% This function will return the char representation for the currency 
% specified.
%
% Note: The Unicode representations are locale specific, so this file may
% not work for some users. If anyone does encounter problems, please post
% the currency and the locale of your machine in the comments. 
%
% Inputs:
%
%       str   :    A character array from the set
%                  {'ALL','AFN','ARS','AWG','AUD','AZN','BSD','BBD','BYR',
%                   'BZD','BMD','BOB','BAM','BWP','BGN','BRL','BND','KHR',
%                   'CAD','KYD','CLP','CNY','COP','CRC','HRK','CUP','CZK',
%                   'DKK','DOP','XCD','EGP','SVC','EEK','EUR','FKP','FJD',
%                   'GHC','GIP','GTQ','GGP','GYD','HNL','HKD','HUF','ISK',
%                   'INR','IDR','IRR','IMP','ILS','JMD','JPY','JEP','KZT',
%                   'KPW','KRW','KGS','LAK','LVL','LBP','LRD','LTL','MKD',
%                   'MYR','MUR','MXN','MNT','MZN','NAD','NPR','ANG','NZD',
%                   'NIO','NGN','KPW','NOK','OMR','PKR','PAB','PYG','PEN',
%                   'PHP','PLN','QAR','RON','RUB','SHP','SAR','RSD','SCR',
%                   'SGD','SBD','SOS','ZAR','KRW','LKR','SEK','CHF','SRD',
%                   'SYP','TWD','THB','TTD','TRL','TVD','UAH','GBP','USD',
%                   'UYU','UZS','VEF','VND','YER','ZWD'}
% Outputs:
%
%       currency :    A character array with the requested currency char.
%
%  2015 - 2016 The MathWorks, Inc.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

str = upper(str); % to allow for non-case sensitivity

switch str 
	 case 'ALL' % Albanian Lek
	 	 currency = char([76, 101, 107]); 
	 case 'AFN' 
	 	 currency = char(1547); 
	 case 'ARS' 
	 	 currency = char(36); 
	 case 'AWG' 
	 	 currency = char(402); 
	 case 'AUD' 
	 	 currency = char(36); 
	 case 'AZN' 
	 	 currency = char([1084, 1072, 1085]); 
	 case 'BSD' 
	 	 currency = char(36); 
	 case 'BBD' 
	 	 currency = char(36); 
	 case 'BYR' 
	 	 currency = char([112, 46]); 
	 case 'BZD' 
	 	 currency = char([66, 90, 36]); 
	 case 'BMD' 
	 	 currency = char(36); 
	 case 'BOB' 
	 	 currency = char([36, 98]); 
	 case 'BAM' 
	 	 currency = char([75, 77]); 
	 case 'BWP' 
	 	 currency = char(80); 
	 case 'BGN' 
	 	 currency = char([1083, 1074]); 
	 case 'BRL' 
	 	 currency = char([82, 36]); 
	 case 'BND' 
	 	 currency = char(36); 
	 case 'KHR' 
	 	 currency = char(6107); 
	 case 'CAD' 
	 	 currency = char(36); 
	 case 'KYD' 
	 	 currency = char(36); 
	 case 'CLP' 
	 	 currency = char(36); 
	 case 'CNY' % Chinese Yuan
	 	 currency = char(165); 
	 case 'COP' % Colombian Peso
	 	 currency = char(36); 
	 case 'CRC' 
	 	 currency = char(8353); 
	 case 'HRK' 
	 	 currency = char([107, 110]); 
	 case 'CUP' 
	 	 currency = char(8369); 
	 case 'CZK' 
	 	 currency = char([75, 269]); 
	 case 'DKK' 
	 	 currency = char([107, 114]); 
	 case 'DOP' 
	 	 currency = char([82, 68, 36]); 
	 case 'XCD' 
	 	 currency = char(36); 
	 case 'EGP' 
	 	 currency = char(163); 
	 case 'SVC' 
	 	 currency = char(36); 
	 case 'EEK' 
	 	 currency = char([107, 114]); 
	 case 'EUR' % Euro
	 	 currency = char(8364); 
	 case 'FKP' 
	 	 currency = char(163); 
	 case 'FJD' 
	 	 currency = char(36); 
	 case 'GHC' 
	 	 currency = char(162); 
	 case 'GIP' 
	 	 currency = char(163); 
	 case 'GTQ' 
	 	 currency = char(81); 
	 case 'GGP' 
	 	 currency = char(163); 
	 case 'GYD' 
	 	 currency = char(36); 
	 case 'HNL' 
	 	 currency = char(76); 
	 case 'HKD' 
	 	 currency = char(36); 
	 case 'HUF' 
	 	 currency = char([70, 116]); 
	 case 'ISK' 
	 	 currency = char([107, 114]); 
	 case 'INR' 
	 	 currency = char(8377); 
	 case 'IDR' 
	 	 currency = char([82, 112]); 
	 case 'IRR' 
	 	 currency = char(65020); 
	 case 'IMP' 
	 	 currency = char(163); 
	 case 'ILS' 
	 	 currency = char(8362); 
	 case 'JMD' 
	 	 currency = char([74, 36]); 
	 case 'JPY' % Japan Yen
	 	 currency = char(165); 
	 case 'JEP' 
	 	 currency = char(163); 
	 case 'KZT' 
	 	 currency = char([1083, 1074]); 
	 case 'KPW' 
	 	 currency = char(8361); 
	 case 'KRW' 
	 	 currency = char(8361); 
	 case 'KGS' 
	 	 currency = char([1083, 1074]); 
	 case 'LAK' 
	 	 currency = char(8365); 
	 case 'LVL' 
	 	 currency = char([76, 115]); 
	 case 'LBP' 
	 	 currency = char(163); 
	 case 'LRD' 
	 	 currency = char(36); 
	 case 'LTL' 
	 	 currency = char([76, 116]); 
	 case 'MKD' 
	 	 currency = char([1076, 1077, 1085]); 
	 case 'MYR' 
	 	 currency = char([82, 77]); 
	 case 'MUR' 
	 	 currency = char(8360); 
	 case 'MXN' 
	 	 currency = char(36); 
	 case 'MNT' 
	 	 currency = char(8366); 
	 case 'MZN' 
	 	 currency = char([77, 84]); 
	 case 'NAD' 
	 	 currency = char(36); 
	 case 'NPR' 
	 	 currency = char(8360); 
	 case 'ANG' 
	 	 currency = char(402); 
	 case 'NZD' 
	 	 currency = char(36); 
	 case 'NIO' 
	 	 currency = char([67, 36]); 
	 case 'NGN' 
	 	 currency = char(8358); 
	 case 'NOK' 
	 	 currency = char([107, 114]); 
	 case 'OMR' 
	 	 currency = char(65020); 
	 case 'PKR' 
	 	 currency = char(8360); 
	 case 'PAB' 
	 	 currency = char([66, 47, 46]); 
	 case 'PYG' 
	 	 currency = char([71, 115]); 
	 case 'PEN' 
	 	 currency = char([83, 47, 46]); 
	 case 'PHP' 
	 	 currency = char(8369); 
	 case 'PLN' 
	 	 currency = char([122, 322]); 
	 case 'QAR' 
	 	 currency = char(65020); 
	 case 'RON' 
	 	 currency = char([108, 101, 105]); 
	 case 'RUB' 
	 	 currency = char([1088, 1091, 1073]); 
	 case 'SHP' 
	 	 currency = char(163); 
	 case 'SAR' 
	 	 currency = char(65020); 
	 case 'RSD' 
	 	 currency = char([1044, 1080, 1085, 46]); 
	 case 'SCR' 
	 	 currency = char(8360); 
	 case 'SGD' 
	 	 currency = char(36); 
	 case 'SBD' 
	 	 currency = char(36); 
	 case 'SOS' 
	 	 currency = char(83); 
	 case 'ZAR' % South Africa RAND
	 	 currency = char(82); 
	 case 'LKR' 
	 	 currency = char(8360); 
	 case 'SEK' 
	 	 currency = char([107, 114]); 
	 case 'CHF' 
	 	 currency = char([67, 72, 70]); 
	 case 'SRD' 
	 	 currency = char(36); 
	 case 'SYP' 
	 	 currency = char(163); 
	 case 'TWD' 
	 	 currency = char([78, 84, 36]); 
	 case 'THB' 
	 	 currency = char(3647); 
	 case 'TTD' 
	 	 currency = char([84, 84, 36]); 
	 case 'TRL' 
	 	 currency = char(8356); 
	 case 'TVD' 
	 	 currency = char(36); 
	 case 'UAH' 
	 	 currency = char(8372); 
	 case 'GBP' % GB pounds (UK)
	 	 currency = char(163); 
	 case 'USD' % US Dollars
	 	 currency = char(36); 
	 case 'UYU' 
	 	 currency = char([36, 85]); 
	 case 'UZS' 
	 	 currency = char([1083, 1074]); 
	 case 'VEF' 
	 	 currency = char([66, 115]); 
	 case 'VND' 
	 	 currency = char(8363); 
	 case 'YER' 
	 	 currency = char(65020); 
	 case 'ZWD' 
	 	 currency = char([90, 36]); 
end
end