function [f,c] = DTLZ7(x)
% DTLZ7 problem is discountinous and separable pareto front
% Contains no constraints
  global nfuneval
%   global nviolate
  global nvar
  global nobj
  global maxfuneval 
    
  [nf,~] = size(x);
  f(:,1) = x(:,1);
  f(:,2) = x(:,2);
  c = [];
  g = zeros(nf,1);
  for i = nobj+1:nvar
    g = g  + x(:,i);
  end
  g = 1.0 + (9.0 / 20.0) * g;
  h = 3.0 - f(:,1).*(1.0 + sin(3.0*pi*f(:,1))) / (1.0 + g) - f(:,2).*(1.0 + sin(3.0*pi*f(:,2)))./(1.0 + g);
  f(:,3) = (1.0 + g) * h;
    
  % Display nfuneval every 10%
  nfuneval = nfuneval + nf;
  if (mod(nfuneval,maxfuneval/10) == 0);
    disp(['feval : ',num2str(nfuneval)]);
%     save(['DTLZ7_NFE_',sprintf('%010d',nfuneval),'.mat'],'objs','vars');
  end
end