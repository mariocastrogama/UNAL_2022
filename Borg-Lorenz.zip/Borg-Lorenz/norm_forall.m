function [euc] = norm_forall(XX,norm_type,ref_point)
% function [euc] = norm_forall(XX,norm_type)
% Estimate the norm of several vectors
%
% Input arguments:
% XX        = [ns,xi] matrix containing the vectors (xi) for which the norm must be estimated 
% norm_type = valid cases are 1, 2 (default), 'Inf', 'Fro'  
%
% Output arguments:
% euc       = [ns,1] matrix containing the norms of each vector
%
% Created by: 
%   Mario Castro Gama
%   m.castrogama@unesco-ihe.org
%   PhD Researcher IWSG, UNESCO-IHE
%   Last Update: 2016.09.22
%
  switch nargin
    case 0
      ndata     = 100;
      nobj      = 3;
      XX        = rand(ndata,nobj);
      norm_type = 2;
      ref_point = zeros(1,nobj);
      euc       = norm_forall(XX,norm_type,ref_point);
    case 1
      nobj = size(XX,2);
      norm_type = 2;
      ref_point = zeros(1,nobj);
      euc = norm_forall(XX,norm_type,ref_point);
    case 2
      [nobj] = size(XX,2);
      % find the norm of each of the solutions
      ref_point = zeros(1,nobj);
      euc = norm_forall(XX,norm_type,ref_point); 
    case 3
      [ndata] = size(XX,1);
      euc     = zeros(ndata,1);
      for ii = 1:ndata
        euc(ii,1) = norm(XX(ii,:)-ref_point,norm_type); 
      end
  end
end