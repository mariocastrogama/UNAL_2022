clc;
clear;
fclose all;
close all;
format long g;

global nfuneval
global nvar
global nobj
global VarMin
global VarMax
global maxfuneval 
global epsilon

nobj = 3;
nvar = nobj+19;
VarMin = zeros(1,nvar);
VarMax = ones(1,nvar);

nfuneval = 0;
maxfuneval = 100000;
epsilon = 0.01*ones(1,nobj);

[vars, objs, runtime] = borg(nvar, nobj, 0, @DTLZ7, maxfuneval, VarMin, VarMax, epsilon);

%%
scatter3(objs(:,1),objs(:,2),objs(:,3))
% OFscales = {'linear';'linear';'linear'};
% OFnames = {'OF_1';'OF_2';'OF_3'};
% [hh] = PlotObjectives3DMv2(objs,OFnames,OFscales,1,3);
% view(120,30);