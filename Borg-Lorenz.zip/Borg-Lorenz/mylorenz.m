function [t,y] = mylorenz(po, yini, T, eps)
% MYLORENZ 
% Function generates the lorenz attractor of the prescribed values
% of parameters rho, sigma, beta
%
%   [X,Y,Z] = mylorenz([RHO,SIGMA,BETA],INITV,T,EPS)
%       X, Y, Z - output vectors of the strange attactor trajectories
%       RHO     - Rayleigh number
%       SIGMA   - Prandtl number
%       BETA    - parameter
%       INITV   - initial point
%       T       - time interval
%       EPS     - ode solver precision
%
% Example.
%        param = [28, 10, 8/3];
%        [t,y] = mylorenz(param);
%        plot3(y(:,1),y(:,2),y(:,3));

  if nargin < 1
    po     = [28, 10, 8/3];
    [t, y] = mylorenz(po);
  end

  if nargin <2;
    yini = [0.00 1.00 1.05];
    T = [0.0 25.0];
    eps = 0.000001;
    [t, y] = mylorenz(po, yini, T, eps);
  end

  rho   = po(1);
  sigma = po(2);
  beta  = po(3);
  options = odeset('RelTol',eps,'AbsTol',[eps eps eps/10]);
  [t,y] = ode45(@(t,y) F(t, y, rho, sigma,  beta), T, yini, options);
  return
end

function dy = F(t, y, rho, sigma, beta)
  % Evaluates the right hand side of the Lorenz system
  % x' = sigma*(y-x)
  % y' = x*(rho - z) - y
  % z' = x*y - beta*z
  % typical values: 
  %   rho   = 28.0;
  %   sigma = 10.0;
  %   beta  = 8/3;
  dy = zeros(3,1);
  dy(1) = sigma*(y(2) - y(1));
  dy(2) = y(1)*(rho - y(3)) - y(2);
  dy(3) = y(1)*y(2) - beta*y(3);
  return
end