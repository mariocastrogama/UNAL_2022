clc;
clear;
fclose all;
close all;

global nislands
global nfuneval
global nviolate
global nvar
global nobj
global ncon
global VarMin
global VarMax
global maxfuneval 
global epsilon

nvar = 3;
ncon = 0;
nobj = 3;
VarMin = [20.0,  5.0   1.0];
VarMax = [35.0, 15.0, 10.0];

nislands   = 1;
nviolate   = 0;
nfuneval   = 0;
maxfuneval = 1000;%1e5;
epsilon    = 0.0001*ones(1,nobj);
tic;
% parameters = {'rngstate', 12345, 'initialPopulationSize', 100};
[vars, objs, const]  = borg(nvar, nobj, ncon, @lorenzcomp, maxfuneval, VarMin, VarMax, epsilon);
total_time = toc;
disp(['Total Time [s] : ',num2str(round(total_time,2))]);
DVscales = {'linear';'linear';'linear'};
OFscales = {'linear';'linear';'linear'};
DVnames = {'X_1';'X_2';'X_3'};
OFnames = {'OF_1';'OF_2';'OF_3'};

%%
for iobj = 1:size(objs,1); 
  obj2(iobj,1) = norm(objs(iobj,:)); 
end;
[a, ibest] = min(obj2);
[tobs,xobs] = mylorenz([28 10 8/3]);
[test,xest] = mylorenz(vars(ibest,:));
% [test,xest] = mylorenz([28 10 2.6]);
% Interpolate nestimated with the original observed times
xqest = interp1(test,xest,tobs);
plotmatrix(xobs,xqest);

%%
% [h1] = PlotDecisionM(vars,DVscales,DVnames);
% [h2] = PlotObjectivesM(objs,OFnames,OFscales);
% byColor = 3;
% bySize  = 2;
% [h3] = PlotObjectives3DM(objs,OFnames,OFscales,byColor,bySize);
% [h4] = PlotOFParallelM(objs,byColor,OFnames);
% ctree = fitctree(objs(:,1:4),objs(:,5),'categorynames',OFnames{1:4});
% view(ctree)

%% save the results
% savefile = ['LORENZ_NFE_',num2str(nfuneval),'.mat'];
% save(savefile)