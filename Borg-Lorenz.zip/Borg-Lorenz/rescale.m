function [Y] = rescale(X,rtype)
% function [Y] = rescale(X,rtype)
% Rescales values of X having each column values between [0, 1]
%
% Input arguments:
% X     : matrix of size [nsamples, ncols] containing values to rescale
% rtype : Defines the renormalization type 
%         'full' renormalization
%         'max' just find proportion to maximum value of each objective
%
% Output arguments:
% Y     : result matrix
%
% Developed by: 
% Mario Castro Gama
% PhD researcher
% 2015-10-01
% Last Update 
% 2017-01-15
% 
% Example:
% X = rand(100,4);
% Y = rescale(X);
% disp(min(Y));
% disp(max(Y));
%

  if isempty(X)
    error('X is empty');
  end
  
  if nargin == 1
    rtype = 'full';
  end
    
  [n,m] = size(X);
  Y = zeros(n,m);
  xmin = min(X);
  xmax = max(X);
  switch rtype
    case 'full'
      for jj = 1:m
        Y(:,jj) = (X(:,jj) - xmin(jj)) / (xmax(jj)-xmin(jj));
      end
    case 'max'
      for jj = 1:m
        Y(:,jj) = X(:,jj) / xmax(jj);
      end
  end
end