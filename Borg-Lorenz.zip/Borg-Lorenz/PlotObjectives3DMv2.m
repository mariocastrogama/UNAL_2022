function [hh,idx] = PlotObjectives3DMv2(varargin)
% version 2
% function [hh,idx] = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals)
%
% Plots the scatters trade-off between Objective Functions obtained as 3D plots
% It helps to visualize any hiden trade-off not visible in low dimensional
% Pareto fronts
%
% When plotting minimization of Objectives it is useful to see if there are
% tradeoffs among the Objectives. One way is to visualize a 3D scatter plot
% of each combination of Objective Functions, then a color palette is
% applied as a function of a 4th Objective Function and finally the sizes
% of the dots are represented by a 5th Objective Function
%
% Input Arguments
% [1] XX1        : matrix of size [ndata, nobjs]
% [2] OFnames    : list of names of the OF's
% [3] OFscales   : Scales of each of the time series
% [4] bycolor    : number of the column to order by color
% [5] bysize     : number of the column to order by size 
% [6] ncolors    : number of colors
% [7] nsizes     : number of sizes
% [8] out_clr    : a palette of colors to use for interpolation [ni x 3]
% [9] xinrange   : [xmin, xmax] two values which define the limits of the variable bycolor, 
%                  if the limits are violated NO inrangeing is performed
% [10] ndecimals : number of decimals of each Objective (required for better display)
% [11] OFtypes   : define if function is for maximization or minimization
%
% Output Arguments
%  hh            : Handle of the figure
%  idx           : indexes of solutions which have been selected
%
% Other requirements 
%  subtightplot.m
%  create_colors.m
%  create_markers.m
%  create_sizes.m
%  create_fignames.m
%  select_screen.m
%  nchoosek.m  "toolbox\...\specfun"
%  unidrnd.m   "toolbox\stats"
%  sortrows.m  "toolbox\...\datafun" 
%
% Created by: 
%   Mario Castro Gama
%   m.castrogama@unesco-ihe.org
%   PhD Researcher IWSG, UNESCO-IHE
%   Last Update: 
%   2015-11-16, modified some coloring and bars
%   2016-05-31, correcting the number of colors that are plot to a limited number. 
%               It will increase speed of computation by limiting the number 
%               of legends in the colorbar
%   2016-06-06, fixed a bug with the number of decimals for display in legend and colorbar.
%   2016-09-01, allowed inrangeing of solutions in specified range with variable xinrange
%   2016-10-01, fixed a bug with the decimals for display for each objective and linked to legend and colorbar
%   2016-11-01, allow to create a GIF, very useful for presentations
%   2016-12-01, fixed the squares behind data to improve contrast of
%               inrangeed data. However, squares do not move when generating a GIF 
%
%  % Test
%   nsub     = 500;
%   XX1      = [1.01+3.55*rand(nsub,1), 3.14+2.01*rand(nsub,1), rand(nsub,1), -1.85+2.03*rand(nsub,1)];
%   out_clr  = [1, 0, 0; 1 1 0; 0 0.65 1];
%   xinrange   = [3.50 3.75];
%   [h3,idx] = PlotObjectives3DMv2(XX1,[],[],2,3,[],[],out_clr,xinrange);
%
  tplot = tic;
  [out_mrk] = create_markers(1);
  sel_fontname     = 'Times';
%   sel_fontname     = 'Lucida Sans';
  sel_fontweight   = 'bold';
  sel_fontsize     = 10;
  sel_fontsize_CLR = 10;
  sel_fontsize_LEG = 10;
  
  sel_FaceAlpha    = 0.5;
  sel_inrangecolor   = [0.5 0.5 0.5];
  legend_sizes     = {};
  sel_marker       = 'o';%'s'; %'v'; %'o'; '^'; % 'square' | 'diamond' | 'v' | '^' | '>' | '<' 
  sel_marker_brush = 'x';
  
  
  FlagStore        = 0;
  FlagStoreNewGIF  = 0;
  rot_angles = [-60; 20];
  
  % Animation of visualization
  % rotation angles of GIF
%   rot_angles = [-60:1:(359-60)]; rot_angles(2,:) = 20 + 0*rot_angles;  % [0:5:359]; % 0:1; %359; %359;
  
%   rot_angles = [ zeros(1,30), (0:-1:-60)]; rot_angles(2,:) = 90 + 0*rot_angles;
%   rot2 = [89:-1:20]; rot2 = cat(1,-60+0*rot2,rot2);
%   rot3 = [-60*ones(1,30); 20*ones(1,30)];
%   rot_angles = cat(2,rot_angles,rot2,rot3); clear rot2 rot3;
  time_delay       = 0;
  FlagChangeLabels = 0;
  iframe           = 0;
  % GIF filename
  % GIFfilename = 'WDN_ns_09_case_10_6.gif';  
  % GIFfilename = 'WATER_3D_RGB_v5.gif';
  % GIFfilename = 'GAA_3D_RGB_v5.gif';
%   GIFfilename = 'test_5.gif';
  % GIFfilename = 'WDN_ns_01_case01_5OBF_v3.gif';
  
  % select which monitor to use 1 or 2
  select_screen(1);
  
  switch nargin
    case 0
      disp(' ');
      disp(' % Running test [250x5]');
      disp('   XX1 = [1.01+3.55*rand(500,1), 3.14+2.01*rand(500,1), rand(500,1), -1.85+2.03*rand(500,1)];');
      disp('   [hh,idx] = PlotObjectives3DMv2(XX1);');
      disp(' ');
      nsub = 250;
      XX1 = [1.01+3.55*rand(nsub,1), 3.14+2.01*rand(nsub,1), rand(nsub,1), -1.85+2.03*rand(nsub,1)];
      [hh,idx] = PlotObjectives3DMv2(XX1);
    case 1
      XX1  = varargin{1};
      
      nobj = size(XX1,2);
      [OFnames, OFscales] = create_fignames(nobj,'obj');
      bycolor   = unidrnd(nobj);
      bysize    = bycolor;
      ncolors   = 6;
      nsizes    = 6;
      out_clr   = [1.00, 0.32, 0.00; 1.00 1.00 0.00; 0.00 0.65 1.00];
      xinrange  = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      ndecimals = create_ndecimals(XX1);
      [OFtypes, ~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 2
      XX1       = varargin{1}; nobj      = size(XX1,2);
      OFnames   = varargin{2};
      
      [~, OFscales] = create_fignames(nobj,'obj');
      bycolor   = unidrnd(nobj);
      bysize    = bycolor;
      ncolors   = 6;
      nsizes    = 6;
      out_clr   = [1.00, 0.32, 0.00; 1.00 1.00 0.00; 0.00 0.65 1.00];
      xinrange  = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      ndecimals = create_ndecimals(XX1);
      [OFtypes, ~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 3
      XX1       = varargin{1}; nobj      = size(XX1,2);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      
      bycolor   = unidrnd(nobj);
      bysize    = bycolor;
      ncolors   = 6;
      nsizes    = 6;
      out_clr   = [1.00, 0.32, 0.00; 1.00 1.00 0.00; 0.00 0.65 1.00];
      xinrange  = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      ndecimals = create_ndecimals(XX1);
      [OFtypes, ~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 4
      XX1       = varargin{1}; nobj = size(XX1,2);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      bycolor   = varargin{4};
      
      bysize    = bycolor;
      ncolors   = 6;
      nsizes    = 6;
      out_clr   = [1.00, 0.32, 0.00; 1.00 1.00 0.00; 0.00 0.65 1.00];
      xinrange  = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      ndecimals = create_ndecimals(XX1);
      [OFtypes, ~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 5
      XX1       = varargin{1}; nobj = size(XX1,2);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      bycolor   = varargin{4};
      bysize    = varargin{5};
      
      ncolors   = 6;
      nsizes    = 6;
      out_clr   = [1.00, 0.32, 0.00; 1.00 1.00 0.00; 0.00 0.65 1.00];
      xinrange  = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      ndecimals = create_ndecimals(XX1);
      [OFtypes, ~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 6
      XX1       = varargin{1}; nobj = size(XX1,2);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      bycolor   = varargin{4};
      bysize    = varargin{5};
      ncolors   = varargin{6};
      
      nsizes    = 6;
      out_clr   = [1.00, 0.32, 0.00; 1.00 1.00 0.00; 0.00 0.65 1.00];
      xinrange  = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      ndecimals = create_ndecimals(XX1);
      [OFtypes, ~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 7
      XX1       = varargin{1}; nobj = size(XX1,2);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      bycolor   = varargin{4};
      bysize    = varargin{5};
      ncolors   = varargin{6};
      nsizes    = varargin{7};
      
      out_clr   = [1.00, 0.32, 0.00; 1.00 1.00 0.00; 0.00 0.65 1.00];
      xinrange  = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      ndecimals = create_ndecimals(XX1);
      [OFtypes, ~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 8
      XX1       = varargin{1}; nobj = size(XX1,2);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      bycolor   = varargin{4};
      bysize    = varargin{5};
      ncolors   = varargin{6};
      nsizes    = varargin{7};
      out_clr   = varargin{8};
      
      xinrange  = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      ndecimals = create_ndecimals(XX1);
      [OFtypes, ~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 9
      XX1       = varargin{1}; nobj = size(XX1,2);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      bycolor   = varargin{4};
      bysize    = varargin{5};
      ncolors   = varargin{6};
      nsizes    = varargin{7};
      out_clr   = varargin{8};
      xinrange  = varargin{9};
      
      ndecimals = create_ndecimals(XX1);
      [OFtypes,~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 10
      XX1       = varargin{1}; nobj = size(XX1,2);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      bycolor   = varargin{4};
      bysize    = varargin{5};
      ncolors   = varargin{6};
      nsizes    = varargin{7};
      out_clr   = varargin{8};
      xinrange  = varargin{9};
      ndecimals = varargin{10};
      
      [OFtypes,~] = create_fignames(nobj,'type');
      [hh,idx]  = PlotObjectives3DMv2(XX1,OFnames,OFscales,bycolor,bysize,ncolors,nsizes,out_clr,xinrange,ndecimals,OFtypes);
      
    case 11
      XX1       = varargin{1}; [ndata,nobj] = size(XX1);
      OFnames   = varargin{2};
      OFscales  = varargin{3};
      bycolor   = varargin{4};
      bysize    = varargin{5};
      ncolors   = varargin{6};
      nsizes    = varargin{7};
      out_clr   = varargin{8};
      xinrange  = varargin{9};
      ndecimals = varargin{10};
      OFtypes   = varargin{11};
      
      if isempty(OFnames)
        [OFnames, ~] = create_fignames(nobj,'obj');
      end
      if isempty(OFscales)
        [~, OFscales] = create_fignames(nobj,'obj');
      end
      if nobj > length(OFnames)
        error(' OFnames are incomplete');
      end
      if nobj > length(OFscales)
        error(' OFscales are incomplete');
      end
      if (nobj < bycolor) || (bycolor < 1)
        error(' bycol is not a feasible value');
      end
      if (nobj < bysize) || (bysize < 1)
        error(' bysize is not a feasible value');
      end
      if isempty(bycolor)
        bycolor = unidrnd(nobj);
      end
      if isempty(bysize)
        bysize = unidrnd(nobj);
      end
      if isempty(ncolors)
        ncolors = 6;
        disp(' setting >> ncolors = 6');
      end
      if isempty(nsizes)
        nsizes = 6;
        disp(' setting >> nsizes = 6');
      end
      if nsizes > 10
        disp(' setting >> nsizes = 10');
        nsizes = 10;
      end
      if ncolors > 10
        disp(' setting >> ncolors = 10');
        ncolors = 10;
      end
      if (bycolor == bysize)
        nsizes = ncolors;
      end
      if isempty(out_clr)
        out_clr = [1.00, 0.42, 0.00; 1.00 1.00 0.00; 0.00 0.65 1.00];
      else
        if (size(out_clr,2)~=3) || (size(out_clr,1)==1)
          error(' Colorpalette must have at least 2 rows (colors) and always 3 columns [r, g, b]');
        end
      end
      if isempty(xinrange)
        xinrange = [min(XX1(:,bycolor))-0.0001, max(XX1(:,bycolor))+0.0001];
      end
      if length(ndecimals) < nobj
        error('vector of number of decimals is less than required');
      end
      if isempty(ndecimals)
        ndecimals = create_ndecimals(XX1);
      end
      
      % this can be set to plot different variables at different precision
      % it indicates the numerical precision of results
      strformat = {};
      for iobj = 1:nobj
        strformat = cat(2,strformat,['%4.',num2str(ndecimals(iobj)),'f']);
      end
      % strformat
      
      if length(OFtypes) < nobj
        error(' length(OFtypes) < nobj');
      end
      % create the types of objectives if not passed
      if isempty(OFtypes)
        [OFtypes, ~] = create_fignames(nobj,'type');
      end
      % This defines the direction of plotting if a certain OF is for
      % minimization or maximization
      xdir = {};
      for itype =1:length(OFtypes)
        if strcmp(OFtypes{itype},'max') ==1
          xdir = cat(2,xdir,'reverse');
        else
          xdir = cat(2,xdir,'normal');
        end
      end
      
      % This is the switch for plotting
      switch nobj
        case {0, 1, 2}
          error('Too few objectives to display');
        case {3, 4, 5, 6, 7, 8}
          % order of combinations of 3 variables for plotting
          ifigs = nchoosek(1:nobj,3);
          ifigs = sortrows(ifigs,3);
          
          % single plot
          % ifigs = ifigs(1,:); 

          % Only plot the figures which do not include the bycolor and
          % bysize columns
          for ii = size(ifigs,1):-1:1
            r1 = length(find(ifigs(ii,:)==bycolor));
            r2 = length(find(ifigs(ii,:)==bysize ));
            irej = r1 + r2;
            if (irej > 0) % get rid of that figure
              ifigs(ii,:) = [];
            end
          end
          clear r1 r2 irej;
          
          nsub  = size(ifigs,1);
          ncols = ceil(sqrt(nsub));
          nrows = ceil(nsub/ncols);
          disp(' ');
          disp('   Plot of 3D trade-offs among objectives');
          disp(['   Figure with nrows : ',num2str(nrows),' and ncolumns : ',num2str(ncols)]);
          disp(['   by Color : OF',num2str(bycolor),' ',OFnames{bycolor}]);
          disp(['   by Size  : OF',num2str(bysize),' ',OFnames{bysize}]);
          if (xinrange(2) < min(XX1(:,bycolor)))
            disp('   Max value of xinrange < min(X(:,bycolor))');
            disp('   Reverting to min and max of bycolor');
            xinrange = [min(XX1(:,bycolor)), max(XX1(:,bycolor))];
          end
          if (xinrange(1) > max(XX1(:,bycolor)))
            disp('   min value of xinrange > max(X(:,bycolor))');
            disp('   Reverting to min and max of bycolor');
            xinrange = [min(XX1(:,bycolor)), max(XX1(:,bycolor))];
          end
          
          make_it_tight = true; 
          % make_it_tight = false;
          %                    subtightplot(m, n, p,  [gap_vert, gap_horz],  [marg_bottom, marg_top], [marg_left, marg right],varargin)
          %
          subplot = @(m,n,p) subtightplot(m, n, p, [0.05, 0.075], [0.075, 0.015], [0.05, 0.225]);
          if ~make_it_tight
            clear subplot;
          end
          
          hh = figure;%(ifig);
          set(hh,'Color',[1.0 1.0 1.0]);
%           set(hh,'Position',[63 1 1538 833]);%[70 10 1400 810]);
%           set(hh,'Position',[1 29 1600 805]);
%          set(hh,'Position',[1 29 1366 675]);
          set(gcf, 'OuterPosition', get(0, 'Screensize'));
%           ranges_var_min = [-1  0 -2  0];
          ranges_var_min = min(XX1); % zeros(1,nobj); %[ 0  0  0  0 0  0  0  0];
          ranges_var_max = max(XX1); % [+10 +20 +20 +10];
          xmin = min([XX1; ranges_var_min]);
          xmax = max([XX1; ranges_var_max]);

          % Selection of a valid range between two different values
          sel_inrange = find((XX1(:,bycolor) > xinrange(1)) & (XX1(:,bycolor) < xinrange(2)) == 1);
          sel_brushed = find((XX1(:,bycolor) <= xinrange(1)) | (XX1(:,bycolor) >= xinrange(2)) == 1);
          
          ninrange  = size(sel_inrange,1);
          XXinrange = XX1(sel_inrange,:);
          
          nbrushed  = size(sel_brushed,1);
          XXbrushed = XX1(sel_brushed,:);
          
          % Estimate maximum and minimum of selection
          xinrangemin = min(XXinrange);
          xinrangemax = max(XXinrange);
          
          % Check if it found any feasible solution inside xinrange, otherwise exit
          if (ninrange == 0)
            error(' The range of the selected variable does not find any feasible solution');
          end
          
          % find best Trade-off point of MOO
          norm_type  = 2;
%           ref_point = [1 1 0 1]
          ref_point = min(XX1);%zeros(1,nobj);%[0 0 0 0 0 0 0 0]
          [euc]      = norm_forall(XXinrange,norm_type,ref_point);
          [~,BTOpos] = min(euc);
          clear euc;
          
          [out_clr] = create_colors(ncolors,out_clr);
          %[ idx, tick_size, tick_color, out_sizes, out_colors ] = create_sizes_v2(XX1,bysize,nsizes,bycolor,ncolors);
          [ idx, tick_size, tick_color, out_sizes, out_colors ] = create_sizes_v2(XXinrange,bysize,nsizes,bycolor,ncolors);
          tick_size
          tick_color
          % Estimate the ranges of nsizes and ncolors once again because it
          % requires to keep only unique values
%           tick_color
          nsizes = max(out_sizes);
          ncolors = max(out_colors);
          [out_clr] = create_colors(ncolors,out_clr);
                    
          % determine the right value for a MAX or MIN objective
          switch xdir{bysize}
            case 'reverse'
              ksize = -1;
              arrow_bysize = '\uparrow';
            case 'normal'
              ksize = +1;
              arrow_bysize = '\downarrow';
          end
          
          for isub = 1:nsub
            x1 = ifigs(isub,1);
            y1 = ifigs(isub,2);
            z1 = ifigs(isub,3);
            subplot(nrows,ncols,isub);
            
            % Draw the series once to get the proper legend with the
            % corresponding sizes. Plot with no color
            % only do it on the last subplot
            if (isub == nsub)
              for isize = 1:nsizes
                xclus = find(out_sizes == isize,1); % only find the first value with that marker size
                if ~isempty(xclus)
                  %plot3(XX1(xclus,x1),XX1(xclus,y1),XX1(xclus,z1),...
                  plot3(XXinrange(xclus,x1),XXinrange(xclus,y1),XXinrange(xclus,z1),...
                    'Marker',sel_marker,... 'Marker',out_mrk{1},...
                    'lineStyle','No',...
                    'Markersize',(10 - isize + 1),...
                    'MarkerEdgecolor',[0.2 0.2 0.2],...
                    'Markerfacecolor','No');
                  hold on;
                  xleg_a = sprintf(strformat{bysize},ksize*tick_size(nsizes-isize+1));
                  xleg_b = sprintf(strformat{bysize},ksize*tick_size(nsizes-isize+2));
                  legend_sizes = cat(2,[xleg_a,' to ',xleg_b],legend_sizes);
                end % ~isempty(xclus);
              end % iclus;
              % Plot the  desired point
%               plot3(xmin(x1),xmin(y1),xmin(z1),...
                plot3(ref_point(x1),ref_point(y1),ref_point(z1),...
                'p','Markersize',20,...
                'linewidth',1,...
                'MarkerEdgecolor','k',...
                'Markerfacecolor','y');
              hold on;
              legend_sizes = cat(2,legend_sizes,'Ideal Point');   
              
              % Plot the Best Trade-Off point 
%               plot3(XX1(BTOpos,x1),XX1(BTOpos,y1),XX1(BTOpos,z1),...
%                 's','Markersize',6,...
%                 'MarkerEdgecolor','k',...
%                 'linewidth',2,...
%                 'Markerfacecolor','w');
%               hold on;
%               legend_sizes = cat(2,legend_sizes,'BTO');

              % plot the brushed data LAST of all
              if nbrushed > 0;
                plot3(XXbrushed(:,x1),XXbrushed(:,y1),XXbrushed(:,z1),...
                  sel_marker_brush,'Markersize',2,...
                  'Markeredgecolor',sel_inrangecolor);
                hold on;
                legend_sizes = cat(2,legend_sizes,'Brushed data');
              end
            end % (isub == n);
            
            % plot the brushed data for all other sublplots
            if nbrushed > 0;
              plot3(XXbrushed(:,x1),XXbrushed(:,y1),XXbrushed(:,z1),...
                sel_marker_brush,'Markersize',2,...
                'Markeredgecolor',sel_inrangecolor);
            end
            hold on;
            
            % The second time we do the classification is when we really
            % draw each of the data points. Plot with color.
            ntot = 0;
            ser  = 0;
            for isize = nsizes:-1:1
              for icolor = ncolors:-1:1
                ser = ser + 1;
                xrange = idx{isize,icolor};
                ndataclus = length(xrange);
                ntot = ntot + ndataclus;
                if (ndataclus > 0)
                  %plot3(XX1(xrange,x1),XX1(xrange,y1),XX1(xrange,z1),...
                  plot3(XXinrange(xrange,x1),XXinrange(xrange,y1),XXinrange(xrange,z1),...
                    'Marker',sel_marker,...'Marker',out_mrk{1},...
                    'lineStyle','No',...
                    'Markersize',(10 - isize + 1),...
                    'Markerfacecolor',out_clr(icolor,:),...
                    'MarkerEdgecolor',out_clr(icolor,:));                    
%                     'MarkerEdgecolor',[0.2 0.2 0.2]);
                end % ndataclus > 0;
                hold on;
              end % icolor;
            end % isize;
            
            % Plot the desired theoretical point
%             plot3(xmin(x1),xmin(y1),xmin(z1),...
            plot3(ref_point(x1),ref_point(y1),ref_point(z1),...
            'p','Markersize',20,...
              'linewidth',1,...
              'MarkerEdgecolor','k',...
              'Markerfacecolor','y');

            % Plot the Best Trade-Off point
%             plot3(XX1(BTOpos,x1),XX1(BTOpos,y1),XX1(BTOpos,z1),...
%               's','Markersize',6,...
%               'MarkerEdgecolor','k',...
%               'linewidth',2,...
%               'Markerfacecolor','w');
            

            % Set current axis properties
            set(gca,'Fontname',sel_fontname);
            set(gca,'Fontsize',sel_fontsize);
            set(gca,'Fontweight',sel_fontweight);
            
            % Set x limits, tick, labelrotation, scale
            nlab = 3;
            xta = [];
            xsa = {};
            
            switch OFtypes{x1}%xdir{x1}
              case 'max'%'reverse';
                kxlabel = -1;
              case 'min'%'normal';
                kxlabel = +1;
            end
            for is = 1:nlab 
              xt = xmin(x1)+(is-1)/(nlab-1)*(xmax(x1)-xmin(x1));
              xs = sprintf(strformat{x1},round(kxlabel*xt,ndecimals(x1)));
%               if (is == 3); xsa{nlab} = cell2mat([xs,' ',OFnames{x1}]); else
              xsa = cat(2,xsa,xs);
              xta = cat(2,xta,xt);
%               end
            end
            set(gca,'xlim', [xmin(x1) xmax(x1)]);
            set(gca,'xtick',xta);
            set(gca,'xticklabel',xsa);      % set(gca,'xticklabelrotation',-42);
            set(gca,'XScale',OFscales{x1}); % set(gca,'xticklabel',xs);
            xlabel(['$',OFnames{x1},'$'],'interpreter','latex'); %,'Rotation',5.25);
%             set(xlab,'HorizontalAlignment','left');
%             set(xlab,'VerticalAlignment','cap'); % 'baseline' 'top' 'cap' 'middle' 'bottom'
%             set(gca,'XDir',xdir{x1});
            
            % Set y limits, tick, scale
            ysa = {}; 
            yta = [];
            switch OFtypes{y1}%xdir{y1}
              case 'max'%'reverse';
                kylabel = -1;
              case 'min'%'normal';
                kylabel = +1;
            end
            for is = 1:nlab
              yt = xmin(y1)+(is-1)/(nlab - 1)*(xmax(y1)-xmin(y1));
              ys = sprintf(strformat{y1},kylabel*round(yt,ndecimals(y1)));
%               if (is == 3); ysa{nlab} = cell2mat([ OFnames{y1},' ',ys]); else
              ysa = cat(2,ysa,ys);
              yta = cat(2,yta,yt);
%               end
            end
            set(gca,'ylim', [xmin(y1) xmax(y1)]);
            set(gca,'ytick',yta);
            set(gca,'yticklabel',ysa);
            set(gca,'YScale',OFscales{y1}); % set(gca,'yticklabel',ys);
            ylabel(['$',OFnames{y1},'$'],'interpreter','latex'); %,'Rotation',-40);
%             set(ylab,'HorizontalAlignment','center');
%             set(gca,'YDir',xdir{y1});
            
            % Set z limits, tick, scale
            zsa = {}; 
            zta = [];
            switch OFtypes{z1}%xdir{z1}
              case 'max'%'reverse';
                kzlabel = -1;
              case 'min'%'normal';
                kzlabel = +1;
            end
            for is = 1:nlab
              zt = xmin(z1)+(is-1)/(nlab - 1)*(xmax(z1)-xmin(z1));
              zs = sprintf(strformat{z1},round(kzlabel*zt,ndecimals(z1))); 
              zsa = cat(2,zsa,zs);
              zta = cat(2,zta,zt);
            end
            set(gca,'zlim', [xmin(z1) xmax(z1)]);
            set(gca,'ztick',zta);
            set(gca,'zticklabel',zsa);
            zlabel(['$',OFnames{z1},'$'],'interpreter','latex');
%             zlab = zlabel(OFnames{z1},'interpreter','latex');
%             set(zlab,'HorizontalAlignment','left');
            set(gca,'ZScale',OFscales{z1});
            axis square;
%             set(gca,'Position',[0.01 0.10 0.80 0.85]);
            
            grid on;
            hv = view(rot_angles(1,1),rot_angles(2,1));
            
            % plot the squared faced behind data for visualization of inrangeed data
            face_color = 0.975*ones(1,3);
            edge_color = (2/3)*face_color;
            frdlt = 80;
            xdlt = min(diff(xta))/frdlt; % xdlt = xdlt(1)/frdlt;
            ydlt = min(diff(yta))/frdlt; % ydlt = ydlt(1)/frdlt;
            zdlt = min(diff(zta))/frdlt; % zdlt = zdlt(1)/frdlt;
            
            for isq = 1:nlab-1
              for jsq = 1:nlab-1
                xface1 = [xta(isq)+xdlt, xta(isq+1)-xdlt, xta(isq+1)-xdlt, xta(isq)+xdlt,   xta(isq)+xdlt];
                yface1 = [yta(jsq)+ydlt, yta(jsq)+ydlt,   yta(jsq+1)-ydlt, yta(jsq+1)-ydlt, yta(jsq)+ydlt];
                patch(xface1,yface1,zta(1)*ones(1,5),face_color,'EdgeColor',edge_color,'FaceAlpha',sel_FaceAlpha);
                hold on;
                xface2 = [xta(isq)+xdlt, xta(isq+1)-xdlt, xta(isq+1)-xdlt, xta(isq)+xdlt,   xta(isq)+xdlt];
                zface2 = [zta(jsq)+zdlt, zta(jsq)+zdlt,   zta(jsq+1)-zdlt, zta(jsq+1)-zdlt, zta(jsq)+zdlt];
                patch(xface2,yta(end)*ones(1,5),zface2,face_color,'EdgeColor',edge_color,'FaceAlpha',sel_FaceAlpha);
                hold on;
                yface3 = [yta(isq)+ydlt, yta(isq+1)-ydlt, yta(isq+1)-ydlt, yta(isq)+ydlt,   yta(isq)+ydlt];
                zface3 = [zta(jsq)+zdlt, zta(jsq)+zdlt,   zta(jsq+1)-zdlt, zta(jsq+1)-zdlt, zta(jsq)+zdlt];
                patch(xta(end)*ones(1,5),yface3,zface3,face_color,'EdgeColor',edge_color,'FaceAlpha',sel_FaceAlpha);
                hold on;
              end
            end
            clear isq jsq;
          end % isub;

          % Set colormap ticks equal number as divisions
          % less than 10 colors is fine
          xclrtick = (0:(1.0/ncolors):1.0);
%           xclrbar = xmin(bycolor) + (xmax(bycolor)-xmin(bycolor))*xclrtick;
%           OFtypes{bycolor}
%           xdir{bycolor}
          switch OFtypes{bycolor}%xdir{bycolor}
            case 'max'%'reverse'
              kclr = -1;
              arrow_bycolor = '\uparrow';
            case 'min'%'normal'
              kclr = +1;
              arrow_bycolor = '\downarrow';
          end
          % Create colorbar ticks labels
          xclrlabel = {};
          for ii = 1:ncolors+1 %length(xclrtick);
%             xclrlabel = cat(2, xclrlabel, sprintf(strformat,xclrbar(ii)));
            xclrlabel = cat(2, xclrlabel, sprintf(strformat{bycolor},kclr*tick_color(ii)));
          end % ii
          
          hc = colorbar('Ticks',xclrtick,...
            'TickLabels',xclrlabel,...
            'Location','manual',...
            'Direction','reverse',...
            'Position',[0.84 0.55 0.05 0.33],...
            'FontSize', sel_fontsize_CLR,...
            'Fontweight','Bold',...
            'colormap',out_clr);

          % Set colorbar title. Thanks to the guys of http://undocumentedmatlab.com/
          % this changed recently between versions you may just need to use
          % something like...
          %
          %      get(hc,'xlabel');
          %      set(get(hc,'xlabel'),'String',['by Color : ',OFnames{bycol}]);
          %
          text('Parent', hc.DecorationContainer, ...            
            'String', ['$Color~:~',arrow_bycolor,'~',OFnames{bycolor},'$'],... %Hazard [10^{6}COP]','$'],... %            'String', ['$Color : ',arrow_bycolor,' Hazard [10^{6}COP]','$'],...
            'FontSize', sel_fontsize_CLR,...
            'Fontweight','Bold',...
            'Position', [-0.05, 1.05, 0], ...
            'Units', 'normalized', ...
            'HorizontalAlignment', 'left', ...
            'VerticalAlignment', 'bottom',...
            'interpreter','latex');
          
          % Set legend. Thanks to the guys of http://undocumentedmatlab.com/
          % this changed recently between versions you may just need to use
          % something like...
          %
          %    text('String',['by Size : ',OFnames{bysize}],'Position',<...>);
          %
          leg = legend(legend_sizes,'Box','Off',...
            'Position',[0.810 0.075 0.125 0.33],...%[0.705 0.50 0.09 0.33],...
            'FontSize', sel_fontsize_LEG,...
            'Fontweight','Bold');
          text('Parent', leg.DecorationContainer, ... %'String', ['$Marker : ',arrow_bysize,' ',OFnames{bysize},'$'], ...
            'String', ['$Marker~:~',arrow_bysize,'~',OFnames{bysize},'$'],... %Hazard [10^{6}COP]','$'],...
            'interpreter','latex',...
            'FontSize', sel_fontsize_LEG,...
            'Fontweight','Bold',...
            'Position', [0.175, 1.05, 0],...
            'Units', 'normalized',...
            'HorizontalAlignment', 'left',...
            'VerticalAlignment', 'bottom');
          
          if (size(rot_angles,2) > 1)
%             for irot = rot_angles;% 0:1;%359;%359;
%               theta = mod(irot,360);
            for irot = 1:size(rot_angles,2)
              theta = mod(rot_angles(1,irot),360);
              phi   = mod(rot_angles(2,irot),360);
              for isub = 1:nsub
                subplot(nrows,ncols,isub);
                view(theta,phi);
%               title(['\theta = ',num2str(theta)],'FontSize', sel_fontsize,'Fontweight','Bold');
                x = get(gca,'xticklabel');
                y = get(gca,'yticklabel');
                theta_cuad = mod(theta,180);
                % Change last element on X axis
%                 if and(((0 <= theta_cuad) && (theta_cuad < 90)),FlagChangeLabels)
%                   x{3} = [x{3}(length(x{1})+2:end),' ',x{3}(1:length(x{1}))];
%                   set(gca,'xticklabel',x);
%                   y{3} = [y{3}(end-length(y{1})+1:end),' ', y{3}(1:end-length(y{1}))];
%                   set(gca,'yticklabel',y); 
%                   FlagChangeLabels = 0;
%                 end
%                 if and(((90 <= theta_cuad) && ( theta_cuad < 180)),~FlagChangeLabels)
%                   x{3} = [x{3}(end-length(x{1})+1:end),' ', x{3}(1:end-length(x{1}))];
%                   set(gca,'xticklabel',x);
%                   y{3} = [y{3}(length(y{1})+1:end),' ',y{3}(1:length(y{1}))];
%                   set(gca,'yticklabel',y);
%                   FlagChangeLabels = 1;
%                 end
              end % isub of rotation for GIF
%               drawnow;
              % Store each frame and build a gif
              if (FlagStore == 1)
%                 frame = getframe(hh);
%                 im    = frame2im(frame);
%                 [imind, cm] = rgb2ind(im,256);
%                 if (FlagStoreNewGIF == 1);              
%                   imwrite(imind,cm,GIFfilename,'gif','DelayTime',time_delay,'Loopcount',inf);
%                   FlagStoreNewGIF = 0;
%                 else
%                   imwrite(imind,cm,GIFfilename,'gif','WriteMode','append','DelayTime',time_delay);
%                 end
                iframe = iframe +1;
                mov(iframe) = getframe(gcf);                
              end % (FlagStore == 1)
            end % irot
          end
        otherwise
          error(' Too many objectives to display, Max{nobj} = 7');
      end % switch nobj
      hold off;
      grid on;
      drawnow;
      
      if FlagStore == 1
        movie2avi(mov,'5OF_solution.avi', 'compression', 'None','fps',10);
      end
      
      % extract the id's of the samples which were inrangeed IN
      if (ninrange < size(XX1,1))
        disp(['   Brushing selection : ',num2str(ninrange),' out of ',num2str(ndata),' samples (',sprintf('%2.1f',ninrange/ndata*100),'%)']);
        for ii = 1:length(idx)
          ki        = length(idx{ii});
          if (ki > 0)
            idx{ii} = sel_inrange(1:ki);
            sel_inrange(1:ki) = [];
          end
        end
      end
      disp(['   plotting time ',sprintf('%2.1f',toc(tplot)),' [s]']);
    otherwise
      error(' Too many input arguments');
  end % switch nargin
end % function